"""Seed demo complaints for Praturu village. Idempotent — safe to run any time:

    cd /app/backend && python seed.py
"""

import asyncio
from datetime import datetime, timedelta, timezone

from lib.db import db, ensure_indexes
from models.complaint import Complaint, ComplaintStatus

SEEDS: list[dict] = [
    {
        "tracking_id": "JS-84A2",
        "villager_name": "Latha Rani",
        "contact_number": "9849123401",
        "problem_type": "leaking_pipe",
        "description": "Main pipeline near the Ward 2 water tank is leaking for three days; "
        "water is pooling on the street.",
        "status": ComplaintStatus.IN_PROGRESS,
        "assigned_authority": "Team A - Pipeline Maintenance",
        "age_hours": 48,
    },
    {
        "tracking_id": "JS-19C4",
        "villager_name": "K. Rajendra",
        "contact_number": "9701123456",
        "problem_type": "unusual_color_smell",
        "description": "Water from the Ward 4 Primary School hand pump looks cloudy and "
        "smells of mud since Monday.",
        "status": ComplaintStatus.PENDING,
        "assigned_authority": None,
        "age_hours": 26,
    },
    {
        "tracking_id": "JS-92E1",
        "villager_name": "Shobha Devi",
        "contact_number": "9000456789",
        "problem_type": "irregular_supply",
        "description": "Morning supply in Ward 1 lasts barely 15 minutes; many houses at "
        "the end of the street get no water.",
        "status": ComplaintStatus.PENDING,
        "assigned_authority": None,
        "age_hours": 9,
    },
    {
        "tracking_id": "JS-77B3",
        "villager_name": "Md. Ilyas",
        "contact_number": "9390112233",
        "problem_type": "dirty_water",
        "description": "The overhead tank was cleaned last week, but sediments still come "
        "from every tap in our lane.",
        "status": ComplaintStatus.RESOLVED,
        "assigned_authority": "Team B - Chlorination & Tank Cleaning",
        "age_hours": 150,
    },
    {
        "tracking_id": "JS-55D9",
        "villager_name": "Venkata Lakshmi",
        "contact_number": "9866778899",
        "problem_type": "leaking_pipe",
        "description": "The public tap near the old temple does not close; water flows "
        "all night.",
        "status": ComplaintStatus.IN_PROGRESS,
        "assigned_authority": "Team A - Pipeline Maintenance",
        "age_hours": 72,
    },
]


async def seed() -> None:
    await ensure_indexes()
    now_utc = datetime.now(timezone.utc)
    inserted = 0
    for s in SEEDS:
        data = {k: v for k, v in s.items() if k != "age_hours"}
        data["created_at"] = now_utc - timedelta(hours=s["age_hours"])
        complaint = Complaint(**data)
        result = await db.complaints.update_one(
            {"tracking_id": complaint.tracking_id},
            {"$setOnInsert": complaint.model_dump()},
            upsert=True,
        )
        if result.upserted_id is not None:
            inserted += 1
        print(f"seeded {complaint.tracking_id} ({complaint.status.value})")
    total = await db.complaints.count_documents({})
    print(f"done: {inserted} new, {total} total complaints")


if __name__ == "__main__":
    asyncio.run(seed())
