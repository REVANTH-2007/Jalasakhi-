"""Village complaint lifecycle: submit, track publicly, and administer."""

import random
import string
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException
from pymongo import ReturnDocument

from lib.db import db
from models.complaint import Complaint, ComplaintCreate, ComplaintUpdate

router = APIRouter(prefix="/complaints", tags=["complaints"])

ALPHABET = string.ascii_uppercase + string.digits


def new_tracking_id() -> str:
    return "JS-" + "".join(random.choices(ALPHABET, k=4))


async def unique_tracking_id() -> str:
    for _ in range(10):
        candidate = new_tracking_id()
        if not await db.complaints.find_one({"tracking_id": candidate}):
            return candidate
    raise HTTPException(status_code=503, detail="could not allocate a tracking id, try again")


def to_model(doc: dict) -> Complaint:
    doc = dict(doc)
    doc.pop("_id", None)
    created = doc.get("created_at")
    # motor returns naive UTC datetimes — re-anchor them so JS Date() parses the offset.
    if isinstance(created, datetime) and created.tzinfo is None:
        doc["created_at"] = created.replace(tzinfo=timezone.utc)
    return Complaint(**doc)


@router.post("", response_model=Complaint, status_code=201)
async def create_complaint(input: ComplaintCreate) -> Complaint:
    complaint = Complaint(tracking_id=await unique_tracking_id(), **input.model_dump())
    await db.complaints.insert_one(complaint.model_dump())
    return complaint


@router.get("", response_model=list[Complaint])
async def list_complaints() -> list[Complaint]:
    docs = await db.complaints.find().sort("created_at", -1).to_list(1000)
    return [to_model(doc) for doc in docs]


@router.get("/{tracking_id}", response_model=Complaint)
async def get_complaint(tracking_id: str) -> Complaint:
    doc = await db.complaints.find_one({"tracking_id": tracking_id.strip().upper()})
    if doc is None:
        raise HTTPException(status_code=404, detail="tracking id not found")
    return to_model(doc)


@router.patch("/{tracking_id}", response_model=Complaint)
async def update_complaint(tracking_id: str, input: ComplaintUpdate) -> Complaint:
    changes = input.model_dump(exclude_unset=True)
    if not changes:
        raise HTTPException(status_code=422, detail="nothing to update")
    doc = await db.complaints.find_one_and_update(
        {"tracking_id": tracking_id.strip().upper()},
        {"$set": changes},
        return_document=ReturnDocument.AFTER,
    )
    if doc is None:
        raise HTTPException(status_code=404, detail="tracking id not found")
    return to_model(doc)
