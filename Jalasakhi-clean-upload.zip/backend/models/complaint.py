"""Complaint models — mirror these by hand in frontend/src/lib/types.ts."""

import uuid
from datetime import datetime, timezone
from enum import Enum

from pydantic import BaseModel, Field


class ProblemType(str, Enum):
    DIRTY_WATER = "dirty_water"
    UNUSUAL_COLOR_SMELL = "unusual_color_smell"
    LEAKING_PIPE = "leaking_pipe"
    IRREGULAR_SUPPLY = "irregular_supply"
    OTHER = "other"


class ComplaintStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class Complaint(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    tracking_id: str  # public handle, format "JS-84A2"
    villager_name: str
    contact_number: str
    problem_type: ProblemType
    description: str
    image_url: str | None = None  # optional data-URL snapshot from the simulated upload
    status: ComplaintStatus = ComplaintStatus.PENDING
    assigned_authority: str | None = None
    created_at: datetime = Field(default_factory=utc_now)


class ComplaintCreate(BaseModel):
    villager_name: str = Field(min_length=2, max_length=80)
    contact_number: str = Field(min_length=10, max_length=15)
    problem_type: ProblemType
    description: str = Field(min_length=10, max_length=2000)
    image_url: str | None = None


class ComplaintUpdate(BaseModel):
    status: ComplaintStatus | None = None
    assigned_authority: str | None = Field(default=None, max_length=80)
