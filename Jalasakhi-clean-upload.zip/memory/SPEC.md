# Jalasakhi — Praturu Village Water Management (SPEC)

## What the app is
Single-page, mobile-first civic utility for rural water management in Praturu village.
Four tab sections on one route (`/`, deep links fall back to `/`):

1. **Report Issue** — complaint form (villager name, 10-digit contact, problem type
   dropdown, description, simulated photo upload with preview). On submit the backend
   generates a Tracking ID `JS-XXXX` (4 random uppercase alphanumerics) shown in a
   success modal with copy / WhatsApp share / "Track now".
2. **Track Complaints** — public board: search by Tracking ID (tolerates missing `JS-`
   prefix / lowercase), status filter pills, "your recent tickets" chips from
   localStorage (`jalasakhi:my_tickets`), live-updating complaint cards (Tracking ID,
   IST date, problem type, description, masked reporter, assigned team, status badge,
   Reported→Assigned→In Progress→Resolved timeline).
3. **Admin Portal** — open management view (NO login by design): desktop table +
   mobile cards; per-complaint status dropdown (pending/in_progress/resolved) and
   "Assign Local Authority" dropdown (4 sanitation teams or unassigned). Optimistic
   PATCH → public board reflects changes instantly (also polled every 4s).
4. **Health Hub** — bilingual EN⇄తెలుగు (global language context; header + hub toggles
   are synced). 4 guidance cards (safe water storage, handwashing, household
   sanitation, reporting contamination) + 3-question hygiene quiz with instant
   green/red answer highlighting, explanations, score screen, retry.

## Data model (`complaints` collection, Mongo db "app")
- `id` uuid4 string, `tracking_id` unique `JS-XXXX`
- `villager_name`, `contact_number`, `problem_type` (dirty_water | unusual_color_smell | leaking_pipe | irregular_supply | other)
- `description`, `image_url` (data URL or null), `status` (pending | in_progress | resolved), `assigned_authority` (string | null), `created_at` (aware UTC)

## API (all under `/api`)
- `POST /api/complaints` → 201 Complaint
- `GET /api/complaints` → list, newest first
- `GET /api/complaints/{tracking_id}` → Complaint | 404
- `PATCH /api/complaints/{tracking_id}` → update status/assigned_authority
- legacy `POST/GET /api/status` probe endpoints remain

## Seed facts (created by `backend/seed.py`, idempotent $setOnInsert)
- JS-84A2 — Latha Rani — leaking pipe — In Progress — Team A - Pipeline Maintenance
- JS-19C4 — K. Rajendra — unusual color/smell — Pending — unassigned
- JS-92E1 — Shobha Devi — irregular supply — Pending — unassigned
- JS-77B3 — Md. Ilyas — dirty water — Resolved — Team B - Chlorination & Tank Cleaning
- JS-55D9 — Venkata Lakshmi — leaking pipe — In Progress — Team A - Pipeline Maintenance

## Auth / credentials
None — the admin portal is open per the user's spec. No accounts, no PINs.

## Notes
- Frontend↔backend contract is hand-mirrored: `backend/models/complaint.py` ↔ `frontend/src/lib/types.ts`.
- "Real-time" = TanStack Query polling (4s) + optimistic admin updates + localStorage for the villager's own ticket IDs.
