import { useRef, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Camera, Loader2, Send, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useLanguage } from "@/context/LanguageContext";
import { apiPost } from "@/lib/api";
import { addMyTicket } from "@/lib/myTickets";
import { problemTypeLabels } from "@/lib/translations";
import {
  PROBLEM_TYPES,
  type Complaint,
  type ComplaintCreate,
  type ProblemType,
} from "@/lib/types";

interface ComplaintFormProps {
  onCreated: (complaint: Complaint) => void;
}

interface PhotoAttachment {
  fileName: string;
  dataUrl: string | null;
}

export default function ComplaintForm({ onCreated }: ComplaintFormProps) {
  const { lang, t } = useLanguage();
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [name, setName] = useState("");
  const [contact, setContact] = useState("");
  const [problemType, setProblemType] = useState<ProblemType | "">("");
  const [description, setDescription] = useState("");
  const [photo, setPhoto] = useState<PhotoAttachment | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const submit = useMutation({
    mutationFn: (body: ComplaintCreate) => apiPost<Complaint>("/complaints", body),
    onSuccess: async (complaint) => {
      addMyTicket(complaint.tracking_id);
      await qc.invalidateQueries({ queryKey: ["complaints"] });
      onCreated(complaint);
      setName("");
      setContact("");
      setProblemType("");
      setDescription("");
      setPhoto(null);
      setErrors({});
    },
    onError: () => toast.error(t.submitFailedToast),
  });

  async function handlePhoto(file: File | undefined | null) {
    if (!file) return;
    if (file.size > 400_000) {
      toast.warning(t.photoTooLarge);
      setPhoto({ fileName: file.name, dataUrl: null });
      return;
    }
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    }).catch(() => null);
    setPhoto({ fileName: file.name, dataUrl });
  }

  function validate(): boolean {
    const next: Record<string, string> = {};
    if (name.trim().length < 2) next.name = t.errName;
    if (!/^\d{10}$/.test(contact.trim())) next.contact = t.errContact;
    if (!problemType) next.problemType = t.errType;
    if (description.trim().length < 10) next.description = t.errDescription;
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    if (!validate()) return;
    submit.mutate({
      villager_name: name.trim(),
      contact_number: contact.trim(),
      problem_type: problemType as ProblemType,
      description: description.trim(),
      image_url: photo?.dataUrl ?? null,
    });
  }

  return (
    <Card className="rounded-2xl border-sky-100 shadow-sm" data-testid="complaint-form">
      <CardHeader className="pb-2">
        <CardTitle className="font-heading text-2xl font-bold text-slate-900">
          {t.formTitle}
        </CardTitle>
        <CardDescription className="text-sm font-medium text-slate-500">
          {t.formSubtitle}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          <div className="space-y-1.5">
            <Label htmlFor="villager-name" className="text-sm font-bold text-slate-700">
              {t.villagerName}
            </Label>
            <Input
              id="villager-name"
              data-testid="complaint-name-input"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={t.villagerNamePh}
              autoComplete="name"
              className="h-12 rounded-xl border-sky-200 text-base"
              aria-invalid={!!errors.name}
            />
            {errors.name && (
              <p className="text-xs font-semibold text-red-600" data-testid="name-error">
                {errors.name}
              </p>
            )}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="contact-number" className="text-sm font-bold text-slate-700">
              {t.contact}
            </Label>
            <Input
              id="contact-number"
              data-testid="complaint-contact-input"
              type="tel"
              inputMode="numeric"
              value={contact}
              onChange={(e) => setContact(e.target.value.replace(/\D/g, "").slice(0, 10))}
              placeholder={t.contactPh}
              autoComplete="tel"
              className="h-12 rounded-xl border-sky-200 text-base"
              aria-invalid={!!errors.contact}
            />
            {errors.contact && (
              <p className="text-xs font-semibold text-red-600" data-testid="contact-error">
                {errors.contact}
              </p>
            )}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="problem-type" className="text-sm font-bold text-slate-700">
              {t.problemType}
            </Label>
            <Select
              value={problemType || null}
              onValueChange={(value) => setProblemType(value as ProblemType)}
            >
              <SelectTrigger
                id="problem-type"
                data-testid="problem-type-select"
                className="h-12 w-full rounded-xl border-sky-200 text-base"
              >
                <SelectValue>
                  {(value: string | null) =>
                    value ? (
                      problemTypeLabels[lang][value as ProblemType]
                    ) : (
                      <span className="text-muted-foreground">{t.chooseType}</span>
                    )
                  }
                </SelectValue>
              </SelectTrigger>
              <SelectContent>
                {PROBLEM_TYPES.map((type) => (
                  <SelectItem key={type} value={type} className="py-2.5 text-base">
                    {problemTypeLabels[lang][type]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.problemType && (
              <p className="text-xs font-semibold text-red-600" data-testid="problem-type-error">
                {errors.problemType}
              </p>
            )}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="problem-description" className="text-sm font-bold text-slate-700">
              {t.description}
            </Label>
            <Textarea
              id="problem-description"
              data-testid="complaint-description-textarea"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={t.descriptionPh}
              rows={4}
              className="rounded-xl border-sky-200 text-base"
              aria-invalid={!!errors.description}
            />
            {errors.description && (
              <p className="text-xs font-semibold text-red-600" data-testid="description-error">
                {errors.description}
              </p>
            )}
          </div>

          <div className="space-y-1.5">
            <Label className="text-sm font-bold text-slate-700">{t.photoLabel}</Label>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              data-testid="photo-input"
              onChange={(e) => {
                void handlePhoto(e.target.files?.[0]);
                e.target.value = "";
              }}
            />
            {!photo ? (
              <button
                type="button"
                data-testid="photo-upload-btn"
                onClick={() => fileRef.current?.click()}
                className="flex h-12 w-full items-center justify-center gap-2 rounded-xl border-2 border-dashed border-sky-300 bg-sky-50 text-sm font-bold text-sky-800 transition-colors hover:bg-sky-100"
              >
                <Camera className="size-5" />
                {t.photoBtn}
              </button>
            ) : (
              <div
                className="flex items-center gap-3 rounded-xl border border-sky-200 bg-sky-50 p-2"
                data-testid="photo-preview"
              >
                {photo.dataUrl ? (
                  <img
                    src={photo.dataUrl}
                    alt={photo.fileName}
                    className="size-14 rounded-lg object-cover"
                  />
                ) : (
                  <span className="flex size-14 items-center justify-center rounded-lg bg-sky-100 text-sky-600">
                    <Camera className="size-6" />
                  </span>
                )}
                <span className="min-w-0 flex-1 truncate text-sm font-semibold text-slate-700">
                  {photo.fileName}
                </span>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  data-testid="photo-remove-btn"
                  onClick={() => setPhoto(null)}
                  aria-label={t.photoRemove}
                >
                  <X className="size-4" />
                </Button>
              </div>
            )}
          </div>

          <Button
            type="submit"
            disabled={submit.isPending}
            data-testid="complaint-submit-btn"
            className="h-13 w-full rounded-xl bg-gradient-to-r from-sky-600 to-teal-600 text-base font-bold text-white shadow-md hover:from-sky-700 hover:to-teal-700"
          >
            {submit.isPending ? (
              <>
                <Loader2 className="size-5 animate-spin" />
                {t.submitting}
              </>
            ) : (
              <>
                <Send className="size-5" />
                {t.submit}
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
