import { useLanguage } from "@/context/LanguageContext";
import { statusLabels } from "@/lib/translations";
import type { ComplaintStatus } from "@/lib/types";

const BADGE_STYLES: Record<ComplaintStatus, string> = {
  pending: "bg-amber-100 text-amber-900 border-amber-300/70",
  in_progress: "bg-sky-100 text-sky-900 border-sky-300/70",
  resolved: "bg-emerald-100 text-emerald-900 border-emerald-300/70",
};

const DOT_STYLES: Record<ComplaintStatus, string> = {
  pending: "bg-amber-500",
  in_progress: "bg-sky-500",
  resolved: "bg-emerald-500",
};

export default function StatusBadge({ status }: { status: ComplaintStatus }) {
  const { lang } = useLanguage();
  return (
    <span
      data-testid={`status-badge-${status}`}
      className={`inline-flex h-7 shrink-0 items-center gap-1.5 rounded-full border px-3 text-xs font-bold whitespace-nowrap ${BADGE_STYLES[status]}`}
    >
      <span className={`size-2 rounded-full ${DOT_STYLES[status]}`} />
      {statusLabels[lang][status]}
    </span>
  );
}
