import { FilePlus2, HeartPulse, Radar, ShieldCheck } from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { useLanguage } from "@/context/LanguageContext";

export type TabId = "report" | "track" | "admin" | "hub";

interface TabNavProps {
  active: TabId;
  onChange: (tab: TabId) => void;
  openCount: number;
}

export default function TabNav({ active, onChange, openCount }: TabNavProps) {
  const { t } = useLanguage();
  const tabs: { id: TabId; label: string; icon: LucideIcon }[] = [
    { id: "report", label: t.tabReport, icon: FilePlus2 },
    { id: "track", label: t.tabTrack, icon: Radar },
    { id: "admin", label: t.tabAdmin, icon: ShieldCheck },
    { id: "hub", label: t.tabHub, icon: HeartPulse },
  ];

  return (
    <nav className="mx-auto max-w-3xl px-4 pt-3" data-testid="tab-nav" aria-label="Sections">
      <div className="grid grid-cols-4 gap-1.5 rounded-2xl border border-sky-100 bg-white p-1.5 shadow-sm">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            type="button"
            data-testid={`tab-${id}`}
            onClick={() => onChange(id)}
            aria-current={active === id}
            className={`relative flex min-h-14 flex-col items-center justify-center gap-0.5 rounded-xl px-1 text-[11px] leading-tight font-bold transition-colors sm:min-h-16 sm:text-xs ${
              active === id
                ? "bg-gradient-to-b from-sky-600 to-sky-700 text-white shadow-md"
                : "text-slate-600 hover:bg-sky-50"
            }`}
          >
            <Icon className="size-5" />
            <span className="text-center">{label}</span>
            {id === "track" && openCount > 0 && (
              <span
                data-testid="open-issues-badge"
                className="absolute top-1 right-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-amber-400 px-1 text-[10px] font-extrabold text-amber-950"
              >
                {openCount}
              </span>
            )}
          </button>
        ))}
      </div>
    </nav>
  );
}
