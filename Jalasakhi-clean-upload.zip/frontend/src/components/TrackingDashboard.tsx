import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, Clock3, Search, UserRound, Wrench, X } from "lucide-react";

import StatusBadge from "@/components/StatusBadge";
import { useLanguage } from "@/context/LanguageContext";
import { formatIST, maskName } from "@/lib/format";
import { getMyTickets } from "@/lib/myTickets";
import { problemTypeLabels, statusLabels } from "@/lib/translations";
import { useComplaints } from "@/lib/useComplaints";
import { COMPLAINT_STATUSES, type Complaint, type ComplaintStatus } from "@/lib/types";

interface TrackingDashboardProps {
  seed: string;
}

function Timeline({ status, labels }: { status: ComplaintStatus; labels: string[] }) {
  const doneCount = status === "resolved" ? 4 : status === "in_progress" ? 3 : 1;
  return (
    <div className="mt-3 flex items-start gap-1" data-testid="status-timeline">
      {labels.map((label, i) => (
        <div key={label} className="flex flex-1 flex-col items-center gap-1">
          <div
            className={`h-1.5 w-full rounded-full ${
              i < doneCount ? "bg-gradient-to-r from-sky-500 to-teal-500" : "bg-slate-200"
            }`}
          />
          <span
            className={`text-center text-[10px] leading-tight font-semibold ${
              i < doneCount ? "text-sky-700" : "text-slate-400"
            }`}
          >
            {label}
          </span>
        </div>
      ))}
    </div>
  );
}

function ComplaintCard({
  complaint,
  problemLabel,
  photoAttached,
  assignedTo,
  unassigned,
  reportedBy,
  timelineLabels,
}: {
  complaint: Complaint;
  problemLabel: string;
  photoAttached: string;
  assignedTo: string;
  unassigned: string;
  reportedBy: string;
  timelineLabels: string[];
}) {
  return (
    <article
      data-testid={`complaint-card-${complaint.tracking_id}`}
      className="rounded-2xl border border-sky-100 bg-white p-4 shadow-sm"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p
            className="font-mono text-lg font-extrabold tracking-wider text-sky-800"
            data-testid="card-tracking-id"
          >
            {complaint.tracking_id}
          </p>
          <p className="mt-0.5 flex items-center gap-1 text-xs text-slate-500">
            <Clock3 className="size-3.5" />
            <time dateTime={complaint.created_at}>{formatIST(complaint.created_at)}</time>
          </p>
        </div>
        <StatusBadge status={complaint.status} />
      </div>

      <span className="mt-2 inline-flex rounded-full border border-teal-200 bg-teal-50 px-2.5 py-0.5 text-xs font-bold text-teal-800">
        {problemLabel}
      </span>

      {complaint.image_url && (
        <div className="mt-2 overflow-hidden rounded-xl" data-testid="complaint-photo">
          <img
            src={complaint.image_url}
            alt={photoAttached}
            className="h-28 w-full object-cover"
          />
        </div>
      )}

      <p className="mt-2 text-sm leading-relaxed text-slate-700">{complaint.description}</p>

      <div className="mt-3 flex flex-wrap items-center justify-between gap-x-3 gap-y-1 border-t border-slate-100 pt-2.5 text-xs text-slate-600">
        <span className="flex items-center gap-1">
          <UserRound className="size-3.5" />
          {reportedBy}: <strong className="font-bold">{maskName(complaint.villager_name)}</strong>
        </span>
        <span
          className={`flex items-center gap-1 font-semibold ${
            complaint.assigned_authority ? "text-emerald-700" : "text-amber-700"
          }`}
          data-testid={`card-assignment-${complaint.tracking_id}`}
        >
          {complaint.assigned_authority ? (
            <>
              <Wrench className="size-3.5" />
              {assignedTo}: {complaint.assigned_authority}
            </>
          ) : (
            unassigned
          )}
        </span>
      </div>

      <Timeline status={complaint.status} labels={timelineLabels} />
    </article>
  );
}

export default function TrackingDashboard({ seed }: TrackingDashboardProps) {
  const { lang, t } = useLanguage();
  const { data, isPending, isError } = useComplaints();
  const [query, setQuery] = useState(seed);
  const [statusFilter, setStatusFilter] = useState<ComplaintStatus | "all">("all");
  const [myTickets] = useState<string[]>(() => getMyTickets());

  useEffect(() => {
    if (seed) setQuery(seed);
  }, [seed]);

  const complaints = useMemo(() => data ?? [], [data]);
  const normalized = query.trim().toUpperCase().replace(/\s+/g, "");
  const searched = useMemo(
    () =>
      complaints.filter((c) => {
        if (!normalized) return true;
        const bare = c.tracking_id.replace("JS-", "");
        const q = normalized.replace(/^JS-?/, "");
        return bare.includes(q) || c.tracking_id.includes(normalized);
      }),
    [complaints, normalized],
  );
  const filtered = searched.filter((c) => statusFilter === "all" || c.status === statusFilter);

  const filters: { value: ComplaintStatus | "all"; label: string }[] = [
    { value: "all", label: t.filterAll },
    ...COMPLAINT_STATUSES.map((s) => ({
      value: s,
      label: statusLabels[lang][s],
    })),
  ];

  return (
    <section data-testid="tracking-dashboard">
      <div className="mb-4">
        <h1 className="font-heading text-2xl font-bold text-slate-900">{t.trackTitle}</h1>
        <p className="text-sm font-medium text-slate-500">{t.trackSubtitle}</p>
      </div>

      <div className="relative">
        <Search className="absolute top-1/2 left-3.5 size-5 -translate-y-1/2 text-sky-500" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t.searchPh}
          data-testid="tracking-search-input"
          aria-label={t.searchPh}
          className="h-13 w-full rounded-2xl border border-sky-200 bg-white pr-11 pl-11 text-base font-semibold text-slate-800 shadow-sm outline-none placeholder:font-normal placeholder:text-slate-400 focus-visible:ring-3 focus-visible:ring-sky-300"
        />
        {query && (
          <button
            type="button"
            data-testid="clear-search-btn"
            onClick={() => setQuery("")}
            aria-label={t.clearSearch}
            className="absolute top-1/2 right-3 flex size-7 -translate-y-1/2 items-center justify-center rounded-full bg-slate-100 text-slate-500 transition-colors hover:bg-slate-200"
          >
            <X className="size-4" />
          </button>
        )}
      </div>

      {myTickets.length > 0 && (
        <div className="mt-3" data-testid="my-tickets">
          <p className="mb-1.5 text-xs font-bold tracking-wide text-slate-500 uppercase">
            {t.myTickets}
          </p>
          <div className="flex flex-wrap gap-1.5">
            {myTickets.map((ticket) => (
              <button
                key={ticket}
                type="button"
                data-testid={`my-ticket-${ticket}`}
                onClick={() => setQuery(ticket)}
                className="h-9 rounded-full border border-sky-200 bg-sky-50 px-3 font-mono text-sm font-bold text-sky-800 transition-colors hover:bg-sky-100"
              >
                {ticket}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="mt-3 flex flex-wrap gap-1.5" data-testid="status-filter-pills">
        {filters.map(({ value, label }) => (
          <button
            key={value}
            type="button"
            data-testid={`filter-pill-${value}`}
            onClick={() => setStatusFilter(value)}
            className={`h-9 min-w-14 rounded-full px-3 text-xs font-bold transition-colors ${
              statusFilter === value
                ? "bg-sky-700 text-white shadow"
                : "border border-sky-200 bg-white text-sky-800 hover:bg-sky-50"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {isError && (
        <p
          className="mt-3 flex items-center gap-2 rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm font-semibold text-amber-900"
          data-testid="live-error-banner"
        >
          <AlertTriangle className="size-4 shrink-0" />
          {t.liveError}
        </p>
      )}

      <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2" data-testid="complaint-board">
        {isPending &&
          [1, 2, 3].map((n) => (
            <div key={n} className="h-44 animate-pulse rounded-2xl bg-slate-200/60" />
          ))}

        {!isPending &&
          filtered.map((c) => (
            <ComplaintCard
              key={c.id}
              complaint={c}
              problemLabel={problemTypeLabels[lang][c.problem_type]}
              photoAttached={t.photoAttached}
              assignedTo={t.assignedTo}
              unassigned={t.unassigned}
              reportedBy={t.reportedBy}
              timelineLabels={[
                t.timelineReported,
                t.timelineAssigned,
                t.timelineProgress,
                t.timelineResolved,
              ]}
            />
          ))}
      </div>

      {!isPending && filtered.length === 0 && (
        <div
          className="mt-6 flex flex-col items-center gap-2 rounded-2xl border border-dashed border-sky-200 bg-white/70 p-8 text-center"
          data-testid="no-results"
        >
          <Search className="size-8 text-sky-300" />
          <p className="text-sm font-semibold text-slate-600">
            {normalized ? t.notFound : t.noResults}
          </p>
        </div>
      )}

      {!isPending && filtered.length > 0 && (
        <p className="mt-3 text-center text-xs font-semibold text-slate-400" data-testid="live-badge">
          <span className="mr-1 inline-block size-2 rounded-full bg-emerald-500" />
          {t.live}
        </p>
      )}
    </section>
  );
}
