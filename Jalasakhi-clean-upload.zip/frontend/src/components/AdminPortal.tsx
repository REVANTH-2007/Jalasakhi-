import { useMutation, useQueryClient } from "@tanstack/react-query";
import { ShieldCheck, Wrench } from "lucide-react";
import { toast } from "sonner";

import StatusBadge from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useLanguage } from "@/context/LanguageContext";
import { apiPatch } from "@/lib/api";
import { formatIST, maskName } from "@/lib/format";
import { problemTypeLabels, statusLabels } from "@/lib/translations";
import { useComplaints } from "@/lib/useComplaints";
import {
  COMPLAINT_STATUSES,
  SANITATION_TEAMS,
  type Complaint,
  type ComplaintStatus,
  type ComplaintUpdate,
} from "@/lib/types";

interface PatchPayload {
  trackingId: string;
  patch: ComplaintUpdate;
}

export default function AdminPortal() {
  const { lang, t } = useLanguage();
  const qc = useQueryClient();
  const { data, isPending, isError } = useComplaints();
  const complaints = data ?? [];

  const update = useMutation({
    mutationFn: ({ trackingId, patch }: PatchPayload) =>
      apiPatch<Complaint>(`/complaints/${trackingId}`, patch),
    onMutate: async ({ trackingId, patch }) => {
      await qc.cancelQueries({ queryKey: ["complaints"] });
      const previous = qc.getQueryData<Complaint[]>(["complaints"]);
      qc.setQueryData<Complaint[]>(["complaints"], (old) =>
        (old ?? []).map((c) =>
          c.tracking_id === trackingId
            ? {
                ...c,
                status: patch.status ?? c.status,
                assigned_authority:
                  patch.assigned_authority !== undefined
                    ? patch.assigned_authority
                    : c.assigned_authority,
              }
            : c,
        ),
      );
      return { previous };
    },
    onError: (_error, _payload, context) => {
      if (context?.previous) qc.setQueryData(["complaints"], context.previous);
      toast.error(t.updateFailedToast);
    },
    onSuccess: (_data, { patch }) => {
      toast.success(patch.status === "resolved" ? t.resolvedToast : t.statusUpdatedToast);
    },
    onSettled: () => qc.invalidateQueries({ queryKey: ["complaints"] }),
  });

  function patchComplaint(complaint: Complaint, patch: ComplaintUpdate) {
    update.mutate({ trackingId: complaint.tracking_id, patch });
  }

  const statusSelect = (c: Complaint, wide = false) => (
    <Select
      value={c.status}
      onValueChange={(value) =>
        patchComplaint(c, { status: value as ComplaintStatus, assigned_authority: c.assigned_authority })
      }
    >
      <SelectTrigger
        data-testid={`admin-status-select-${c.tracking_id}`}
        aria-label={t.colStatus}
        className={`h-11 rounded-xl border-sky-200 bg-white text-sm font-bold ${wide ? "w-full" : "w-36"}`}
      >
        <SelectValue>
          {(value: string | null) => statusLabels[lang][(value ?? c.status) as ComplaintStatus]}
        </SelectValue>
      </SelectTrigger>
      <SelectContent>
        {COMPLAINT_STATUSES.map((s) => (
          <SelectItem key={s} value={s} className="py-2.5">
            {statusLabels[lang][s]}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );

  const assignSelect = (c: Complaint, wide = false) => (
    <Select
      value={c.assigned_authority ?? "unassigned"}
      onValueChange={(value) =>
        patchComplaint(c, {
          assigned_authority: value === "unassigned" ? null : value,
          status: c.status,
        })
      }
    >
      <SelectTrigger
        data-testid={`admin-assign-select-${c.tracking_id}`}
        aria-label={t.colAssign}
        className={`h-11 rounded-xl border-sky-200 bg-white text-sm font-semibold ${wide ? "w-full" : "w-56"}`}
      >
        <SelectValue>
          {(value: string | null) => (value && value !== "unassigned" ? value : t.chooseTeam)}
        </SelectValue>
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="unassigned" className="py-2.5">
          {t.chooseTeam}
        </SelectItem>
        {SANITATION_TEAMS.map((team) => (
          <SelectItem key={team} value={team} className="py-2.5">
            {team}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );

  return (
    <section data-testid="admin-portal">
      <div className="mb-4 rounded-2xl bg-gradient-to-r from-sky-900 to-teal-900 p-4 text-white shadow-md sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <span className="flex size-11 items-center justify-center rounded-xl bg-white/15">
              <ShieldCheck className="size-6" />
            </span>
            <div>
              <h1 className="font-heading text-xl font-bold" data-testid="admin-title">
                {t.adminTitle}
              </h1>
              <p className="text-xs font-medium text-sky-100">{t.adminSubtitle}</p>
            </div>
          </div>
          <span
            className="inline-flex h-7 items-center rounded-full bg-amber-400 px-3 text-xs font-extrabold text-amber-950"
            data-testid="staff-only-badge"
          >
            {t.staffOnly}
          </span>
        </div>
        <p className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1 text-xs font-bold" data-testid="admin-count">
          <Wrench className="size-3.5" />
          {complaints.length} {t.totalComplaints}
        </p>
      </div>

      {isError && (
        <p
          className="mb-3 rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm font-semibold text-amber-900"
          data-testid="admin-error-banner"
        >
          {t.liveError}
        </p>
      )}

      {isPending ? (
        <div className="space-y-3">
          {[1, 2, 3].map((n) => (
            <div key={n} className="h-24 animate-pulse rounded-2xl bg-slate-200/60" />
          ))}
        </div>
      ) : complaints.length === 0 ? (
        <p
          className="rounded-2xl border border-dashed border-sky-200 bg-white/70 p-8 text-center text-sm font-semibold text-slate-600"
          data-testid="admin-empty"
        >
          {t.noResults}
        </p>
      ) : (
        <>
          {/* Desktop table */}
          <div className="hidden overflow-hidden rounded-2xl border border-sky-100 bg-white shadow-sm md:block" data-testid="admin-table">
            <Table>
              <TableHeader>
                <TableRow className="bg-sky-50/60 hover:bg-sky-50/60">
                  <TableHead className="text-xs font-extrabold tracking-wide text-slate-600 uppercase">{t.colTracking}</TableHead>
                  <TableHead className="text-xs font-extrabold tracking-wide text-slate-600 uppercase">{t.colDate}</TableHead>
                  <TableHead className="text-xs font-extrabold tracking-wide text-slate-600 uppercase">{t.colProblem}</TableHead>
                  <TableHead className="text-xs font-extrabold tracking-wide text-slate-600 uppercase">{t.colComplaint}</TableHead>
                  <TableHead className="text-xs font-extrabold tracking-wide text-slate-600 uppercase">{t.colStatus}</TableHead>
                  <TableHead className="text-xs font-extrabold tracking-wide text-slate-600 uppercase">{t.colAssign}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {complaints.map((c) => (
                  <TableRow key={c.id} data-testid={`admin-row-${c.tracking_id}`}>
                    <TableCell className="font-mono text-sm font-extrabold text-sky-800">
                      {c.tracking_id}
                    </TableCell>
                    <TableCell className="text-xs text-slate-500">{formatIST(c.created_at)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <StatusBadge status={c.status} />
                      </div>
                      <span className="mt-1 block text-xs font-bold text-teal-700">
                        {problemTypeLabels[lang][c.problem_type]}
                      </span>
                      <span className="block text-xs text-slate-500">{maskName(c.villager_name)}</span>
                    </TableCell>
                    <TableCell className="max-w-64">
                      <span className="block truncate text-sm text-slate-700" title={c.description}>
                        {c.description}
                      </span>
                    </TableCell>
                    <TableCell>{statusSelect(c)}</TableCell>
                    <TableCell>{assignSelect(c)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Mobile cards */}
          <div className="space-y-3 md:hidden">
            {complaints.map((c) => (
              <div
                key={c.id}
                data-testid={`admin-card-${c.tracking_id}`}
                className="space-y-3 rounded-2xl border border-sky-100 bg-white p-4 shadow-sm"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-mono text-base font-extrabold text-sky-800">{c.tracking_id}</p>
                    <p className="text-xs text-slate-500">{formatIST(c.created_at)}</p>
                  </div>
                  <StatusBadge status={c.status} />
                </div>
                <div>
                  <p className="text-xs font-extrabold tracking-wide text-teal-700 uppercase">
                    {problemTypeLabels[lang][c.problem_type]} • {maskName(c.villager_name)}
                  </p>
                  <p className="mt-1 text-sm leading-relaxed text-slate-700">{c.description}</p>
                </div>
                <div className="space-y-2">
                  {statusSelect(c, true)}
                  {assignSelect(c, true)}
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </section>
  );
}
