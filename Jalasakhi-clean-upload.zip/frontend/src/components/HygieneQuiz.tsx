import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { toast } from "sonner";
import { CheckCircle2, Info, RotateCcw, Trophy, XCircle } from "lucide-react";

import { Button } from "@/components/ui/button";
import { useLanguage } from "@/context/LanguageContext";
import { pick, QUIZ } from "@/lib/translations";

export default function HygieneQuiz() {
  const { lang, t } = useLanguage();
  const [questionIdx, setQuestionIdx] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>(() => QUIZ.map(() => null));
  const [finished, setFinished] = useState(false);

  const question = QUIZ[questionIdx];
  const chosen = answers[questionIdx] ?? null;
  const score = answers.filter((a, i) => a !== null && a === QUIZ[i]?.correct).length;

  function choose(optionIdx: number) {
    if (chosen !== null) return;
    setAnswers((prev) => prev.map((a, i) => (i === questionIdx ? optionIdx : a)));
  }

  function next() {
    if (questionIdx + 1 < QUIZ.length) {
      setQuestionIdx(questionIdx + 1);
    } else {
      setFinished(true);
      toast.success(`${t.quizDoneToast}: ${score}/${QUIZ.length}`);
    }
  }

  function retry() {
    setQuestionIdx(0);
    setAnswers(QUIZ.map(() => null));
    setFinished(false);
  }

  const optionClass = (idx: number): string => {
    if (chosen === null) {
      return "border-sky-200 bg-white text-slate-800 hover:border-sky-400 hover:bg-sky-50";
    }
    if (idx === question.correct) {
      return "border-green-600 bg-green-500 text-white shadow-md";
    }
    if (idx === chosen) {
      return "border-red-600 bg-red-500 text-white shadow-md";
    }
    return "border-slate-200 bg-white text-slate-400";
  };

  return (
    <div
      className="mt-8 rounded-2xl border border-sky-100 bg-white p-4 shadow-sm sm:p-6"
      data-testid="hygiene-quiz"
    >
      <div className="mb-4 text-center">
        <h2 className="font-heading text-xl font-bold text-slate-900">{t.quizTitle}</h2>
        <p className="text-sm font-medium text-slate-500">{t.quizSubtitle}</p>
      </div>

      <AnimatePresence mode="wait">
        {finished ? (
          <motion.div
            key="score"
            data-testid="quiz-score-card"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center gap-3 rounded-2xl border-2 border-dashed border-sky-200 bg-sky-50 p-6 text-center"
          >
            <span className="flex size-16 items-center justify-center rounded-full bg-amber-100 text-amber-600">
              <Trophy className="size-8" />
            </span>
            <p className="text-sm font-bold tracking-wide text-sky-700 uppercase">{t.yourScore}</p>
            <p className="font-heading text-5xl font-extrabold text-sky-800" data-testid="quiz-score">
              {score}/{QUIZ.length}
            </p>
            <p className="text-sm font-semibold text-slate-600">
              {score === QUIZ.length ? t.perfectMsg : score >= 2 ? t.goodMsg : t.tryImproveMsg}
            </p>
            <Button
              type="button"
              onClick={retry}
              data-testid="quiz-retry-btn"
              className="h-12 rounded-xl bg-gradient-to-r from-sky-600 to-teal-600 text-base font-bold text-white hover:from-sky-700 hover:to-teal-700"
            >
              <RotateCcw className="size-5" />
              {t.retryBtn}
            </Button>
          </motion.div>
        ) : (
          <motion.div
            key={`question-${questionIdx}`}
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -24 }}
            transition={{ duration: 0.22 }}
          >
            <div className="mb-3 flex items-center justify-between gap-3">
              <p className="text-sm font-extrabold text-sky-700" data-testid="quiz-progress">
                {t.questionWord} {questionIdx + 1} {t.ofWord} {QUIZ.length}
              </p>
              <div className="h-2 w-28 overflow-hidden rounded-full bg-slate-200">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-sky-500 to-teal-500 transition-all duration-300"
                  style={{ width: `${((questionIdx + 1) / QUIZ.length) * 100}%` }}
                />
              </div>
            </div>

            <p className="text-lg leading-snug font-bold text-slate-900" data-testid="quiz-question">
              {pick(question.question, lang)}
            </p>

            <div className="mt-4 grid gap-2">
              {question.options.map((option, idx) => (
                <button
                  key={idx}
                  type="button"
                  data-testid={`quiz-option-${questionIdx}-${idx}`}
                  onClick={() => choose(idx)}
                  disabled={chosen !== null}
                  className={`flex min-h-12 w-full items-center justify-between gap-3 rounded-xl border-2 px-4 py-3 text-left text-base font-bold transition-colors ${
                    optionClass(idx)
                  } ${chosen !== null && idx !== question.correct && idx !== chosen ? "opacity-50" : ""}`}
                >
                  <span>{pick(option, lang)}</span>
                  {chosen !== null && idx === question.correct && (
                    <CheckCircle2 className="size-5 shrink-0" data-testid="quiz-correct-icon" />
                  )}
                  {chosen !== null && idx === chosen && idx !== question.correct && (
                    <XCircle className="size-5 shrink-0" data-testid="quiz-wrong-icon" />
                  )}
                </button>
              ))}
            </div>

            {chosen !== null && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 flex items-start gap-2 rounded-xl border border-sky-200 bg-sky-50 p-3"
                data-testid="quiz-explanation"
              >
                <Info className="mt-0.5 size-4 shrink-0 text-sky-600" />
                <p className="text-sm leading-relaxed font-semibold text-slate-700">
                  <strong className="font-extrabold text-sky-800">
                    {chosen === question.correct ? t.correctWord : t.incorrectWord}
                  </strong>{" "}
                  {pick(question.explanation, lang)}
                </p>
              </motion.div>
            )}

            {chosen !== null && (
              <Button
                type="button"
                onClick={next}
                data-testid={questionIdx + 1 < QUIZ.length ? "quiz-next-btn" : "quiz-finish-btn"}
                className="mt-4 h-12 w-full rounded-xl bg-sky-700 text-base font-bold text-white hover:bg-sky-800"
              >
                {questionIdx + 1 < QUIZ.length ? t.nextBtn : t.seeScore}
              </Button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
