import { CheckCircle2, Copy, MessageCircle, SearchCheck } from "lucide-react";
import { motion } from "motion/react";
import { toast } from "sonner";

import { buttonVariants, Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useLanguage } from "@/context/LanguageContext";
import type { Complaint } from "@/lib/types";

interface SuccessModalProps {
  complaint: Complaint | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onTrack: (trackingId: string) => void;
}

export default function SuccessModal({ complaint, open, onOpenChange, onTrack }: SuccessModalProps) {
  const { t } = useLanguage();
  if (!complaint) return <Dialog open={false} onOpenChange={onOpenChange} />;

  const shareText = encodeURIComponent(
    `Jalasakhi — my complaint ${complaint.tracking_id} about Praturu village water supply is registered.`,
  );

  function copyId() {
    try {
      void navigator.clipboard.writeText(complaint?.tracking_id ?? "");
      toast.success(t.copiedToast);
    } catch {
      toast.error(t.copyId);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="rounded-2xl border-sky-100 sm:max-w-sm"
        data-testid="success-modal"
      >
        <DialogHeader>
          <DialogTitle className="sr-only">{t.successTitle}</DialogTitle>
          <DialogDescription className="sr-only">{t.successMsg}</DialogDescription>
        </DialogHeader>
        <motion.div
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 260, damping: 18 }}
          className="flex flex-col items-center gap-3 text-center"
        >
          <span className="flex size-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
            <CheckCircle2 className="size-9" />
          </span>
          <h2 className="font-heading text-2xl font-bold text-slate-900" data-testid="success-title">
            {t.successTitle}
          </h2>
          <p className="text-sm leading-relaxed text-slate-600">{t.successMsg}</p>
          <div className="w-full rounded-2xl border-2 border-dashed border-sky-300 bg-sky-50 px-4 py-4">
            <p className="text-xs font-bold tracking-wide text-sky-700 uppercase">
              {t.trackingIdLabel}
            </p>
            <p
              className="mt-1 font-heading text-4xl font-extrabold tracking-[0.18em] text-sky-800"
              data-testid="success-tracking-id"
            >
              {complaint.tracking_id}
            </p>
          </div>
          <div className="grid w-full grid-cols-1 gap-2">
            <Button
              type="button"
              variant="outline"
              className="h-12 rounded-xl border-sky-200"
              data-testid="copy-tracking-id-btn"
              onClick={copyId}
            >
              <Copy className="size-4" />
              {t.copyId}
            </Button>
            <a
              href={`https://wa.me/?text=${shareText}`}
              target="_blank"
              rel="noopener noreferrer"
              data-testid="whatsapp-share-link"
              className={buttonVariants({ variant: "secondary" }) + " flex h-12 rounded-xl items-center justify-center gap-2 text-sm font-semibold"}
            >
              <MessageCircle className="size-4" />
              {t.whatsappShare}
            </a>
            <Button
              type="button"
              className="h-12 rounded-xl bg-sky-700 text-white hover:bg-sky-800"
              data-testid="track-now-btn"
              onClick={() => {
                onTrack(complaint.tracking_id);
                onOpenChange(false);
              }}
            >
              <SearchCheck className="size-5" />
              {t.trackNow}
            </Button>
          </div>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}
