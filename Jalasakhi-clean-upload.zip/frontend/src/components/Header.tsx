import { Droplets, Phone } from "lucide-react";

import { useLanguage } from "@/context/LanguageContext";
import type { Lang } from "@/lib/types";

export default function Header() {
  const { lang, setLang, t } = useLanguage();
  return (
    <header className="sticky top-0 z-40 border-b border-sky-100 bg-white/90 shadow-sm backdrop-blur-md">
      <div className="mx-auto flex max-w-3xl items-center justify-between gap-3 px-4 py-3">
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-sky-600 via-sky-500 to-teal-500 text-white shadow-md">
            <Droplets className="size-6" />
          </span>
          <div className="min-w-0">
            <p className="truncate font-heading text-lg leading-tight font-bold text-slate-900">
              జలసఖి <span className="text-sky-600">Jalasakhi</span>
            </p>
            <p className="truncate text-xs font-semibold text-teal-700">{t.village}</p>
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <a
            href="tel:1916"
            data-testid="helpline-link"
            className="hidden h-9 items-center gap-1.5 rounded-full border border-sky-200 bg-sky-50 px-3 text-xs font-bold text-sky-800 transition-colors hover:bg-sky-100 sm:inline-flex"
          >
            <Phone className="size-3.5" />
            {t.helpline}
          </a>
          <div
            className="flex items-center rounded-full border border-sky-200 bg-sky-50 p-0.5"
            data-testid="language-toggle-header"
          >
            {(["en", "te"] as Lang[]).map((l) => (
              <button
                key={l}
                type="button"
                data-testid={`lang-btn-${l}`}
                onClick={() => setLang(l)}
                className={`h-8 min-w-11 rounded-full px-2 text-xs font-bold transition-colors ${
                  lang === l ? "bg-sky-600 text-white shadow" : "text-sky-800 hover:bg-sky-100"
                }`}
              >
                {l === "en" ? "EN" : "తె"}
              </button>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
}
