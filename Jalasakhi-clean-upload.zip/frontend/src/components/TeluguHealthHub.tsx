import { CheckCircle2, Droplets, Hand, Home, Siren } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { motion } from "motion/react";

import HygieneQuiz from "@/components/HygieneQuiz";
import { useLanguage } from "@/context/LanguageContext";
import { HUB_CARDS, pick } from "@/lib/translations";
import type { Lang } from "@/lib/types";

const ICONS: Record<string, LucideIcon> = {
  droplets: Droplets,
  hand: Hand,
  home: Home,
  siren: Siren,
};

const TONES: Record<string, { card: string; icon: string; check: string }> = {
  teal: { card: "bg-teal-50 border-teal-200", icon: "bg-teal-600", check: "text-teal-600" },
  sky: { card: "bg-sky-50 border-sky-200", icon: "bg-sky-600", check: "text-sky-600" },
  emerald: { card: "bg-emerald-50 border-emerald-200", icon: "bg-emerald-600", check: "text-emerald-600" },
  rose: { card: "bg-rose-50 border-rose-200", icon: "bg-rose-600", check: "text-rose-600" },
};

export default function TeluguHealthHub() {
  const { lang, setLang, t } = useLanguage();

  return (
    <section data-testid="health-hub">
      <div className="mb-4 text-center">
        <h1 className="font-heading text-2xl font-bold text-slate-900">{t.hubTitle}</h1>
        <p className="text-sm font-medium text-slate-500">{t.hubSubtitle}</p>
      </div>

      {/* Prominent fluid language toggle */}
      <div
        className="relative mx-auto flex w-full max-w-xs rounded-full border border-sky-200 bg-white p-1 shadow-sm"
        data-testid="language-toggle-btn"
        role="group"
      >
        <motion.span
          className="absolute inset-y-1 left-1 w-[calc(50%-0.25rem)] rounded-full bg-gradient-to-r from-sky-600 to-teal-600 shadow"
          animate={{ x: lang === "te" ? "100%" : "0%" }}
          transition={{ type: "spring", stiffness: 300, damping: 26 }}
        />
        {(["en", "te"] as Lang[]).map((l) => (
          <button
            key={l}
            type="button"
            data-testid={`hub-lang-${l}`}
            onClick={() => setLang(l)}
            className={`relative z-10 h-11 flex-1 rounded-full text-sm font-extrabold transition-colors ${
              lang === l ? "text-white" : "text-sky-800"
            }`}
          >
            {l === "en" ? "English" : "తెలుగు"}
          </button>
        ))}
      </div>

      <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2">
        {HUB_CARDS.map((card, index) => {
          const Icon = ICONS[card.icon];
          const tone = TONES[card.tone];
          return (
            <motion.article
              key={card.icon}
              data-testid={`guidance-card-${card.icon}`}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              className={`rounded-2xl border p-4 shadow-sm ${tone.card}`}
            >
              <div className="flex items-center gap-3">
                <span className={`flex size-11 shrink-0 items-center justify-center rounded-xl text-white shadow ${tone.icon}`}>
                  <Icon className="size-6" />
                </span>
                <h2 className="font-heading text-lg leading-snug font-bold text-slate-900">
                  {pick(card.title, lang)}
                </h2>
              </div>
              <ul className="mt-3 space-y-2">
                {card.checklist.map((item, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm leading-relaxed font-semibold text-slate-700">
                    <CheckCircle2 className={`mt-0.5 size-4.5 shrink-0 ${tone.check}`} />
                    {pick(item, lang)}
                  </li>
                ))}
              </ul>
            </motion.article>
          );
        })}
      </div>

      <HygieneQuiz />
    </section>
  );
}
