import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";

import AdminPortal from "@/components/AdminPortal";
import ComplaintForm from "@/components/ComplaintForm";
import Header from "@/components/Header";
import SuccessModal from "@/components/SuccessModal";
import TabNav, { type TabId } from "@/components/TabNav";
import TeluguHealthHub from "@/components/TeluguHealthHub";
import TrackingDashboard from "@/components/TrackingDashboard";
import { Toaster } from "@/components/ui/sonner";
import { LanguageProvider, useLanguage } from "@/context/LanguageContext";
import { useComplaints } from "@/lib/useComplaints";
import type { Complaint } from "@/lib/types";

function Shell() {
  const { t } = useLanguage();
  const [active, setActive] = useState<TabId>("report");
  const [seed, setSeed] = useState("");
  const [success, setSuccess] = useState<Complaint | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const { data } = useComplaints();
  const openCount = (data ?? []).filter((c) => c.status !== "resolved").length;

  function handleTrackRequest(trackingId: string) {
    setSeed(trackingId);
    setActive("track");
  }

  // Tab-bar navigation clears a stale seeded search so the public board shows everything again.
  function changeTab(tab: TabId) {
    setSeed("");
    setActive(tab);
  }

  return (
    <div className="min-h-svh bg-[#F0F9FF]" data-testid="app-shell">
      <Header />
      <TabNav active={active} onChange={changeTab} openCount={openCount} />

      <main className="mx-auto w-full max-w-3xl px-4 py-5 sm:py-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.22 }}
          >
            {active === "report" && (
              <ComplaintForm
                onCreated={(complaint) => {
                  setSuccess(complaint);
                  setModalOpen(true);
                }}
              />
            )}
            {active === "track" && <TrackingDashboard seed={seed} />}
            {active === "admin" && <AdminPortal />}
            {active === "hub" && <TeluguHealthHub />}
          </motion.div>
        </AnimatePresence>
      </main>

      <footer className="border-t border-sky-100 bg-white/70 py-5 text-center text-xs font-semibold text-slate-500">
        జలసఖి Jalasakhi • {t.village} • {t.helpline}
      </footer>

      <SuccessModal
        complaint={success}
        open={modalOpen}
        onOpenChange={setModalOpen}
        onTrack={handleTrackRequest}
      />
      <Toaster richColors />
    </div>
  );
}

export default function Home() {
  return (
    <LanguageProvider>
      <Shell />
    </LanguageProvider>
  );
}
