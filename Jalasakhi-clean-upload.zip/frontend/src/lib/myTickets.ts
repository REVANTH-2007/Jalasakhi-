// The villager's own submitted tracking IDs — localStorage convenience so they can
// re-track their tickets with one tap. The source of truth stays on the server.

const KEY = "jalasakhi:my_tickets";

export function getMyTickets(): string[] {
  try {
    const raw = localStorage.getItem(KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((x): x is string => typeof x === "string").slice(0, 6);
  } catch {
    return [];
  }
}

export function addMyTicket(trackingId: string): void {
  const next = [trackingId, ...getMyTickets().filter((t) => t !== trackingId)].slice(0, 6);
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    // storage blocked or full — non-fatal, the ID is also in the success modal
  }
}
