/** Mask a villager's name for public display: "Latha Rani" -> "Latha R." */
export function maskName(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0] ?? "";
  return `${parts[0]} ${(parts[1]?.[0] ?? "").toUpperCase()}.`;
}

/** Format a server ISO timestamp for display in IST (Praturu's audience). */
export function formatIST(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString("en-IN", {
    timeZone: "Asia/Kolkata",
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
}
