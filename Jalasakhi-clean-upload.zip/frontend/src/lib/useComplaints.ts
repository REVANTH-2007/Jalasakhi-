import { useQuery } from "@tanstack/react-query";

import { apiGet } from "./api";
import type { Complaint } from "./types";

/** Shared live feed of all village complaints — polled so admin edits appear
 *  on the public board within seconds, without a page reload. */
export function useComplaints() {
  return useQuery({
    queryKey: ["complaints"],
    queryFn: () => apiGet<Complaint[]>("/complaints"),
    refetchInterval: 4000,
  });
}
