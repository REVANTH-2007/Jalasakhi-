// Hand-written mirrors of the Pydantic models in backend/models/complaint.py.
// Nothing infers across the HTTP boundary — keep these in sync with the Python side.

export type ProblemType =
  | "dirty_water"
  | "unusual_color_smell"
  | "leaking_pipe"
  | "irregular_supply"
  | "other";

export type ComplaintStatus = "pending" | "in_progress" | "resolved";

export type Lang = "en" | "te";

export interface Complaint {
  id: string;
  tracking_id: string;
  villager_name: string;
  contact_number: string;
  problem_type: ProblemType;
  description: string;
  image_url: string | null;
  status: ComplaintStatus;
  assigned_authority: string | null;
  created_at: string;
}

export interface ComplaintCreate {
  villager_name: string;
  contact_number: string;
  problem_type: ProblemType;
  description: string;
  image_url: string | null;
}

export interface ComplaintUpdate {
  status?: ComplaintStatus | null;
  assigned_authority?: string | null;
}

export const PROBLEM_TYPES: ProblemType[] = [
  "dirty_water",
  "unusual_color_smell",
  "leaking_pipe",
  "irregular_supply",
  "other",
];

export const COMPLAINT_STATUSES: ComplaintStatus[] = [
  "pending",
  "in_progress",
  "resolved",
];

export const SANITATION_TEAMS = [
  "Team A - Pipeline Maintenance",
  "Team B - Chlorination & Tank Cleaning",
  "Team C - Motor Repair",
  "Team D - Source & Tanker Supply",
];
