import type { ComplaintStatus, Lang, ProblemType } from "./types";

/** Small {en, te} payload — pick the string with `pick(bilingual, lang)`. */
export interface Bilingual {
  en: string;
  te: string;
}

export function pick(text: Bilingual, lang: Lang): string {
  return text[lang];
}

export const problemTypeLabels: Record<Lang, Record<ProblemType, string>> = {
  en: {
    dirty_water: "Dirty Water",
    unusual_color_smell: "Unusual Color/Smell",
    leaking_pipe: "Leaking Pipe",
    irregular_supply: "Irregular Supply",
    other: "Other",
  },
  te: {
    dirty_water: "మురికి నీరు",
    unusual_color_smell: "అసాధారణ రంగు/వాసన",
    leaking_pipe: "పైపు లీకేజీ",
    irregular_supply: "క్రమరహిత సరఫరా",
    other: "ఇతర",
  },
};

export const statusLabels: Record<Lang, Record<ComplaintStatus, string>> = {
  en: { pending: "Pending", in_progress: "In Progress", resolved: "Resolved" },
  te: { pending: "పెండింగ్", in_progress: "జరుగుతోంది", resolved: "పరిష్కరించారు" },
};

export interface Dict {
  // header + tabs
  appTagline: string;
  village: string;
  helpline: string;
  language: string;
  tabReport: string;
  tabTrack: string;
  tabAdmin: string;
  tabHub: string;
  openIssues: string;
  live: string;
  // form
  formTitle: string;
  formSubtitle: string;
  villagerName: string;
  villagerNamePh: string;
  contact: string;
  contactPh: string;
  problemType: string;
  chooseType: string;
  description: string;
  descriptionPh: string;
  photoLabel: string;
  photoBtn: string;
  photoRemove: string;
  photoTooLarge: string;
  submit: string;
  submitting: string;
  errName: string;
  errContact: string;
  errType: string;
  errDescription: string;
  submitFailedToast: string;
  // success modal
  successTitle: string;
  successMsg: string;
  trackingIdLabel: string;
  copyId: string;
  copiedToast: string;
  whatsappShare: string;
  trackNow: string;
  // tracking
  trackTitle: string;
  trackSubtitle: string;
  searchPh: string;
  myTickets: string;
  filterAll: string;
  noResults: string;
  notFound: string;
  clearSearch: string;
  reportedBy: string;
  assignedTo: string;
  unassigned: string;
  liveError: string;
  timelineReported: string;
  timelineAssigned: string;
  timelineProgress: string;
  timelineResolved: string;
  photoAttached: string;
  resolvedToast: string;
  // admin
  adminTitle: string;
  adminSubtitle: string;
  staffOnly: string;
  colTracking: string;
  colProblem: string;
  colComplaint: string;
  colStatus: string;
  colAssign: string;
  colDate: string;
  chooseTeam: string;
  statusUpdatedToast: string;
  updateFailedToast: string;
  totalComplaints: string;
  // hub
  hubTitle: string;
  hubSubtitle: string;
  quizTitle: string;
  quizSubtitle: string;
  questionWord: string;
  ofWord: string;
  correctWord: string;
  incorrectWord: string;
  nextBtn: string;
  seeScore: string;
  yourScore: string;
  perfectMsg: string;
  goodMsg: string;
  tryImproveMsg: string;
  retryBtn: string;
  quizDoneToast: string;
}

export const translations: Record<Lang, Dict> = {
  en: {
    appTagline: "Jalasakhi • Your Water Friend",
    village: "Praturu Grama Panchayat",
    helpline: "Helpline 1916",
    language: "English",
    tabReport: "Report Issue",
    tabTrack: "Track Complaints",
    tabAdmin: "Admin Portal",
    tabHub: "Health Hub",
    openIssues: "open",
    live: "Live",
    formTitle: "Report a Water Problem",
    formSubtitle: "Fill the form below — our team acts within 48 hours.",
    villagerName: "Villager Name",
    villagerNamePh: "e.g. Latha Rani",
    contact: "Contact Number",
    contactPh: "10-digit mobile number",
    problemType: "Problem Type",
    chooseType: "Choose a problem type",
    description: "Describe the Problem",
    descriptionPh: "Where is it? Since when? How bad is it?",
    photoLabel: "Photo Evidence (optional)",
    photoBtn: "Attach Photo",
    photoRemove: "Remove",
    photoTooLarge: "Photo is too large — attaching the name only",
    submit: "Submit Complaint",
    submitting: "Submitting…",
    errName: "Please enter your name",
    errContact: "Enter a valid 10-digit mobile number",
    errType: "Choose a problem type",
    errDescription: "Describe the problem in a few words",
    submitFailedToast: "Could not submit — check your connection and try again",
    successTitle: "Complaint Registered!",
    successMsg: "Save this Tracking ID to check your complaint status anytime.",
    trackingIdLabel: "Your Tracking ID",
    copyId: "Copy ID",
    copiedToast: "Tracking ID copied",
    whatsappShare: "Share on WhatsApp",
    trackNow: "Track Complaint",
    trackTitle: "Live Complaint Board",
    trackSubtitle: "Every village complaint, updated live.",
    searchPh: "Enter Tracking ID e.g. JS-84A2",
    myTickets: "Your recent tickets",
    filterAll: "All",
    noResults: "No complaints match this filter.",
    notFound: "No complaint found for this Tracking ID yet.",
    clearSearch: "Clear search",
    reportedBy: "Reported by",
    assignedTo: "Assigned to",
    unassigned: "Not yet assigned",
    liveError: "Could not reach the village server — showing last known data.",
    timelineReported: "Reported",
    timelineAssigned: "Assigned",
    timelineProgress: "In Progress",
    timelineResolved: "Resolved",
    photoAttached: "Photo attached",
    resolvedToast: "Wonderful — glad it is fixed!",
    adminTitle: "Panchayat Admin Portal",
    adminSubtitle: "Praturu Grama Sachivalayam • Rural Water Supply",
    staffOnly: "For village staff only",
    colTracking: "Tracking ID",
    colProblem: "Problem",
    colComplaint: "Complaint",
    colStatus: "Status",
    colAssign: "Assign Local Authority",
    colDate: "Date",
    chooseTeam: "— Unassigned —",
    statusUpdatedToast: "Complaint updated — public board refreshed",
    updateFailedToast: "Update failed — please try again",
    totalComplaints: "complaints",
    hubTitle: "Health & Hygiene Hub",
    hubSubtitle: "Simple daily habits for safe water",
    quizTitle: "Hygiene Quiz",
    quizSubtitle: "3 questions — tap an answer!",
    questionWord: "Question",
    ofWord: "of",
    correctWord: "Correct!",
    incorrectWord: "Not correct",
    nextBtn: "Next Question",
    seeScore: "See My Score",
    yourScore: "Your Score",
    perfectMsg: "Perfect! You are a true water friend!",
    goodMsg: "Well done — one more revision helps!",
    tryImproveMsg: "Read the cards above and try again.",
    retryBtn: "Try Again",
    quizDoneToast: "Quiz finished",
  },
  te: {
    appTagline: "జలసఖి • మీ నీటి స్నేహితుడు",
    village: "ప్రతూరు గ్రామ పంచాయతీ",
    helpline: "హెల్ప్‌లైన్ 1916",
    language: "తెలుగు",
    tabReport: "ఫిర్యాదు చేయండి",
    tabTrack: "ఫిర్యాదులు చూడండి",
    tabAdmin: "అడ్మిన్ పోర్టల్",
    tabHub: "ఆరోగ్య కేంద్రం",
    openIssues: "పెండింగ్",
    live: "ప్రత్యక్షం",
    formTitle: "నీటి సమస్యను నివేదించండి",
    formSubtitle: "క్రింది ఫారమ్ పూరించండి — మా బృందం 48 గంటల్లో చర్య తీసుకుంటుంది.",
    villagerName: "గ్రామస్తుల పేరు",
    villagerNamePh: "ఉదా: లతారాణి",
    contact: "ఫోన్ నంబర్",
    contactPh: "10 అంకెల మొబైల్ నంబర్",
    problemType: "సమస్య రకం",
    chooseType: "సమస్య రకాన్ని ఎంచుకోండి",
    description: "సమస్యను వివరించండి",
    descriptionPh: "ఎక్కడ? ఎప్పటినుండి? ఎంత తీవ్రం?",
    photoLabel: "ఫోటో ఆధారం (ఐచ్ఛికం)",
    photoBtn: "ఫోటో జోడించండి",
    photoRemove: "తీసివేయండి",
    photoTooLarge: "ఫోటో చాలా పెద్దది — పేరు మాత్రమే జోడిస్తున్నాము",
    submit: "ఫిర్యాదు పంపండి",
    submitting: "పంపుతోంది…",
    errName: "దయచేసి మీ పేరు నమోదు చేయండి",
    errContact: "సరైన 10 అంకెల మొబైల్ నంబర్ నమోదు చేయండి",
    errType: "సమస్య రకాన్ని ఎంచుకోండి",
    errDescription: "కొన్ని మాటల్లో సమస్యను వివరించండి",
    submitFailedToast: "పంపడం విఫలమైంది — కనెక్షన్ తనిఖీ చేసి మళ్ళీ ప్రయత్నించండి",
    successTitle: "ఫిర్యాదు నమోదైంది!",
    successMsg: "మీ ఫిర్యాదు స్థితిని తెలుసుకోవడానికి ఈ ట్రాకింగ్ IDని దాచుకోండి.",
    trackingIdLabel: "మీ ట్రాకింగ్ ID",
    copyId: "ID కాపీ చేయండి",
    copiedToast: "ట్రాకింగ్ ID కాపీ అయింది",
    whatsappShare: "WhatsAppలో పంచండి",
    trackNow: "ఫిర్యాదు చూడండి",
    trackTitle: "ప్రత్యక్ష ఫిర్యాదు బోర్డు",
    trackSubtitle: "గ్రామంలోని ప్రతి ఫిర్యాదు, ప్రతిక్షణం అప్‌డేట్.",
    searchPh: "ట్రాకింగ్ ID నమోదు చేయండి, ఉదా: JS-84A2",
    myTickets: "మీ ఇటీవలి టికెట్లు",
    filterAll: "అన్నీ",
    noResults: "ఈ ఫిల్టర్‌కు ఫిర్యాదులు లేవు.",
    notFound: "ఈ ట్రాకింగ్ ID తో ఇంకా ఫిర్యాదు లేదు.",
    clearSearch: "శోధన తీసివేయండి",
    reportedBy: "ఫిర్యాదు చేసినవారు",
    assignedTo: "కేటాయించిన బృందం",
    unassigned: "ఇంకా కేటాయించలేదు",
    liveError: "సర్వర్‌ను చేరలేకపోయాము — తెలిసిన డేటా చూపుతున్నాము.",
    timelineReported: "నమోదైంది",
    timelineAssigned: "కేటాయింపు",
    timelineProgress: "జరుగుతోంది",
    timelineResolved: "పరిష్కరించారు",
    photoAttached: "ఫోటో జోడించారు",
    resolvedToast: "చాలా సంతోషం — సమస్య పరిష్కరించబడింది!",
    adminTitle: "పంచాయతీ అడ్మిన్ పోర్టల్",
    adminSubtitle: "ప్రతూరు గ్రామ సచివాలయం • గ్రామీణ నీటి సరఫరా",
    staffOnly: "గ్రామ ఉద్యోగుల కోసం మాత్రమే",
    colTracking: "ట్రాకింగ్ ID",
    colProblem: "సమస్య",
    colComplaint: "ఫిర్యాదు",
    colStatus: "స్థితి",
    colAssign: "స్థానిక అధికారిని కేటాయించండి",
    colDate: "తేదీ",
    chooseTeam: "— కేటాయింపు లేదు —",
    statusUpdatedToast: "ఫిర్యాదు అప్‌డేట్ అయింది — పబ్లిక్ బోర్డు రిఫ్రెష్ అయింది",
    updateFailedToast: "అప్‌డేట్ విఫలమైంది — మళ్ళీ ప్రయత్నించండి",
    totalComplaints: "ఫిర్యాదులు",
    hubTitle: "ఆరోగ్య & పరిశుభ్రత కేంద్రం",
    hubSubtitle: "సురక్షిత నీటి కోసం రోజూ చేసే సులభమైన అలవాట్లు",
    quizTitle: "పరిశుభ్రత క్విజ్",
    quizSubtitle: "3 ప్రశ్నలు — సమాధానం నొక్కండి!",
    questionWord: "ప్రశ్న",
    ofWord: "/",
    correctWord: "సరైన సమాధానం!",
    incorrectWord: "సరైన సమాధానం కాదు",
    nextBtn: "తర్వాతి ప్రశ్న",
    seeScore: "నా స్కోరు చూడండి",
    yourScore: "మీ స్కోరు",
    perfectMsg: "అద్భుతం! మీరు నిజమైన జలసఖి!",
    goodMsg: "బాగుంది — ఒకసారి మరింత చదవండి!",
    tryImproveMsg: "పై కార్డులు చదివి మళ్ళీ ప్రయత్నించండి.",
    retryBtn: "మళ్ళీ ప్రయత్నించండి",
    quizDoneToast: "క్విజ్ పూర్తయింది",
  },
};

export interface HubCardData {
  icon: "droplets" | "hand" | "home" | "siren";
  tone: "teal" | "sky" | "emerald" | "rose";
  title: Bilingual;
  checklist: Bilingual[];
}

export const HUB_CARDS: HubCardData[] = [
  {
    icon: "droplets",
    tone: "teal",
    title: { en: "Safe Water Storage సురక్షిత నీటి నిల్వ", te: "సురక్షిత నీటి నిల్వ Safe Water Storage" },
    checklist: [
      { en: "Always store drinking water in a covered container.", te: "తాగునీటిని ఎప్పుడూ మూత ఉన్న పాత్రలో దాచండి." },
      { en: "Use a clean ladle — never dip hands or glasses.", te: "శుభ్రమైన గరిటె వాడండి — చేతులు లేదా గ్లాసులు నీటిలో ఆనించవద్దు." },
      { en: "Wash storage pots weekly with soap and dry them in sun.", te: "వారానికోసారి పాత్రలను సబ్బుతో కడగి, ఎండలో ఆరబెట్టండి." },
      { en: "Keep pots off the floor and away from waste.", te: "పాత్రలను నేల నుండి, చెత్త నుండి దూరంగా ఉంచండి." },
    ],
  },
  {
    icon: "hand",
    tone: "sky",
    title: { en: "Handwashing చేతులు కడుక్కోవడం", te: "చేతులు కడుక్కోవడం Handwashing" },
    checklist: [
      { en: "Wet hands, apply soap, and scrub for 20 full seconds.", te: "చేతులు తడియించి, సబ్బు రుద్ది, 20 సెకన్లు రాసుకోండి." },
      { en: "Clean between fingers, thumbs, and under nails.", te: "వేళ్ల మధ్య, బొటనవేళ్లు, గోర్ల కింద శుభ్రం చేయండి." },
      { en: "Wash before cooking, before eating, and after the toilet.", te: "వంట ముందు, తినే ముందు, మరుగుదొడ్డి తర్వాత తప్పక కడగండి." },
      { en: "Dry with a clean cloth or in open air.", te: "శుభ్రమైన గుడ్డతో లేదా గాలిలో ఆరబెట్టుకోండి." },
    ],
  },
  {
    icon: "home",
    tone: "emerald",
    title: { en: "Household Sanitation ఇంటి పరిశుభ్రత", te: "ఇంటి పరిశుభ్రత Household Sanitation" },
    checklist: [
      { en: "Put waste only in the bin — never near wells or taps.", te: "చెత్తను బుట్టలో మాత్రమే వేయండి — బావులు, ట్యాప్‌ల దగ్గర వేయవద్దు." },
      { en: "Keep water points dry; drain stagnant pools daily.", te: "నీటి ప్రాంతాలను పొడిగా ఉంచండి; నిలిచిన నీటిని రోజూ తోడండి." },
      { en: "Clean drains weekly to stop mosquitoes and flies.", te: "దోమలు, ఈగలను ఆపడానికి గారడీలను వారానికి శుభ్రం చేయండి." },
      { en: "Wash cattle areas far away from the water source.", te: "పశువుల ప్రాంతాలను నీటి వనరుల నుండి దూరంగా కడగండి." },
    ],
  },
  {
    icon: "siren",
    tone: "rose",
    title: { en: "Reporting Contamination కాలుష్యాన్ని నివేదించడం", te: "కాలుష్యాన్ని నివేదించడం Reporting Contamination" },
    checklist: [
      { en: "Diarrhoea, vomiting, or fever? See the ANM or doctor fast.", te: "విరోచాలాలు, వాంతులు, జ్వరం? వెంటనే ఆరోగ్య కార్యకర్త లేదా వైద్యుడిని చూడండి." },
      { en: "Stop drinking that water; boil it or use tanker supply.", te: "ఆ నీరు తాగకండి; మరిగించి తాగండి లేదా ట్యాంకర్ నీరు వాడండి." },
      { en: "Report dirty or smelly water in the Report tab the same day.", te: "మురికి లేదా వాసన నీటిని అదే రోజు 'ఫిర్యాదు' ట్యాబ్‌లో నివేదించండి." },
      { en: "Tell ASHA workers early — quick reporting saves lives.", te: "ASHA కార్యకర్తలకు వెంటనే చెప్పండి — త్వరగా నివేదిస్తే ప్రాణాలు నిలుస్తాయి." },
    ],
  },
];

export interface QuizData {
  question: Bilingual;
  options: Bilingual[];
  correct: number;
  explanation: Bilingual;
}

export const QUIZ: QuizData[] = [
  {
    question: {
      en: "How many seconds should you scrub your hands with soap?",
      te: "సబ్బుతో చేతులు ఎన్ని సెకన్లు రాసుకోవాలి?",
    },
    options: [
      { en: "5 seconds", te: "5 సెకన్లు" },
      { en: "20 seconds", te: "20 సెకన్లు" },
      { en: "2 minutes", te: "2 నిమిషాలు" },
    ],
    correct: 1,
    explanation: {
      en: "20 seconds of soap scrubbing removes most germs.",
      te: "20 సెకన్లు సబ్బుతో రాసుకోవడం వల్ల చాలా సూక్ష్మక్రిములు పోతాయి.",
    },
  },
  {
    question: {
      en: "Which container is best for storing drinking water?",
      te: "తాగునీటిని దాచడానికి ఏ పాత్ర మెరును?",
    },
    options: [
      { en: "An open bucket", te: "తెరిచిన బక్కెట్" },
      { en: "A covered pot with a clean ladle", te: "మూత ఉన్న పాత్ర, శుభ్రమైన గరిటె" },
      { en: "An uncovered steel drum", te: "మూత లేని స్టీల్ డ్రమ్" },
    ],
    correct: 1,
    explanation: {
      en: "A lid keeps dust, flies, and insects out of your water.",
      te: "మూత ఉంచడం వల్ల ధూళి, ఈగలు, కీటకాలు నీటిలో పడవు.",
    },
  },
  {
    question: {
      en: "The village water looks cloudy and smells strange. What do you do first?",
      te: "గ్రామ నీరు మబ్బుగా ఉంది, వాసన వస్తోంది. మొదట ఏమి చేయాలి?",
    },
    options: [
      { en: "Boil it and report in the Report tab", te: "మరిగించి, 'ఫిర్యాదు' ట్యాబ్‌లో నివేదించండి" },
      { en: "Keep drinking it as usual", te: "మామూలుగా తాగుతూనే ఉండండి" },
      { en: "Store it for later use", te: "తర్వాత వాడటానికి దాచండి" },
    ],
    correct: 0,
    explanation: {
      en: "Boiling kills germs, and reporting alerts the panchayat team.",
      te: "మరగించడం వల్ల సూక్ష్మక్రిములు నశిస్తాయి; నివేదిస్తే పంచాయతీ బృందానికి తెలుస్తుంది.",
    },
  },
];
