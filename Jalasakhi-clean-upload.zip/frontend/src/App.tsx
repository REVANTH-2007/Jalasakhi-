import { Routes, Route } from "react-router-dom";
import Home from "@/pages/Home";

// Single-page app: "/" and any deep link render the same tabbed shell.
// BrowserRouter already wraps this in main.tsx.
export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="*" element={<Home />} />
    </Routes>
  );
}
